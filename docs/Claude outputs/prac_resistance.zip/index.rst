.. PC-Science-and-language documentation master file.
.. Use https://emojipedia.org/repeat-button/ for icons/emojis
.. https://emojidb.org/maths-emojis
.. 📚🖹


====================================================
PC-Science-and-language
====================================================

.. toctree::
    :maxdepth: 2
    :caption: ✍️ Introduction
    :numbered:

    introduction/introduction.rst


.. toctree::
    :maxdepth: 2
    :caption: 🤔🌱 Y7 ch 2&3 Short Summaries

    summaries/Y7_ch23_short/2A_short.rst
    summaries/Y7_ch23_short/2B_short.rst
    summaries/Y7_ch23_short/2C_short.rst
    summaries/Y7_ch23_short/2D_short.rst
    summaries/Y7_ch23_short/3A_short.rst
    summaries/Y7_ch23_short/3B_short.rst
    summaries/Y7_ch23_short/3C_short.rst
    summaries/Y7_ch23_short/3D_short.rst
    summaries/Y7_ch23_short/3E_short.rst
    summaries/Y7_ch23_short/flashquiz.rst
    summaries/Y7_ch23_short/flashcards.rst



.. toctree::
    :maxdepth: 2
    :caption: 🤔🌱 Y7 ch 2 Biology Summaries

    summaries/Y7_ch2/2A.rst
    summaries/Y7_ch2/2B.rst
    summaries/Y7_ch2/2C.rst
    summaries/Y7_ch2/2D.rst
    summaries/Y7_ch2/flashquiz.rst
    summaries/Y7_ch2/flashcards.rst

    .. summaries/Y7_ch2/2A_glossary_flashquiz.rst
    .. summaries/Y7_ch2/2B_glossary_flashquiz.rst
    .. summaries/Y7_ch2/2C_glossary_flashquiz.rst
    .. summaries/Y7_ch2/2D_glossary_flashquiz.rst



.. toctree::
    :maxdepth: 2
    :caption: 🤔🌱 Y7 ch 2 Biology Quizzes

    quizzes/Y7_ch2/2A_jumblewords.rst
    quizzes/Y7_ch2/2A_keyterms.rst
    quizzes/Y7_ch2/2A_mcq.rst

    quizzes/Y7_ch2/2B_jumblewords.rst
    quizzes/Y7_ch2/2B_keyterms.rst
    quizzes/Y7_ch2/2B_mcq.rst

    quizzes/Y7_ch2/2C_jumblewords.rst
    quizzes/Y7_ch2/2C_keyterms.rst
    quizzes/Y7_ch2/2C_mcq.rst

    quizzes/Y7_ch2/2D_jumblewords.rst
    quizzes/Y7_ch2/2D_keyterms.rst
    quizzes/Y7_ch2/2D_mcq.rst



.. toctree::
    :maxdepth: 1
    :caption: 🤔🌱 Y7 ch 3 Biology Summaries

    summaries/Y7_ch3/3A.rst
    summaries/Y7_ch3/3B.rst
    summaries/Y7_ch3/3C.rst
    summaries/Y7_ch3/3D.rst
    summaries/Y7_ch3/3E.rst
    summaries/Y7_ch3/flashquiz.rst
    summaries/Y7_ch3/flashcards.rst

    .. summaries/Y7_ch3/3A_glossary_flashquiz.rst
    .. summaries/Y7_ch3/3B_glossary_flashquiz.rst
    .. summaries/Y7_ch3/3C_glossary_flashquiz.rst
    .. summaries/Y7_ch3/3D_glossary_flashquiz.rst
    .. summaries/Y7_ch3/3E_glossary_flashquiz.rst



.. toctree::
    :maxdepth: 1
    :caption: 🤔🌱 Y7 ch 3 Biology Quizzes

    quizzes/Y7_ch3/3A_jumblewords.rst
    quizzes/Y7_ch3/3A_keyterms.rst
    quizzes/Y7_ch3/3A_mcq.rst

    quizzes/Y7_ch3/3B_jumblewords.rst
    quizzes/Y7_ch3/3B_keyterms.rst
    quizzes/Y7_ch3/3B_mcq.rst

    quizzes/Y7_ch3/3C_jumblewords.rst
    quizzes/Y7_ch3/3C_keyterms.rst
    quizzes/Y7_ch3/3C_mcq.rst

    quizzes/Y7_ch3/3D_jumblewords.rst
    quizzes/Y7_ch3/3D_keyterms.rst
    quizzes/Y7_ch3/3D_mcq.rst

    quizzes/Y7_ch3/3E_jumblewords.rst
    quizzes/Y7_ch3/3E_keyterms.rst
    quizzes/Y7_ch3/3E_mcq.rst




.. toctree::
    :maxdepth: 2
    :caption: 🤔⚡ Y8 ch6&7 Short Summaries

    summaries/Y8_ch67_short/6A_short.rst
    summaries/Y8_ch67_short/6B_short.rst
    summaries/Y8_ch67_short/6C_short.rst
    summaries/Y8_ch67_short/6D_short.rst
    summaries/Y8_ch67_short/7A_short.rst
    summaries/Y8_ch67_short/7B_short.rst
    summaries/Y8_ch67_short/7C_short.rst
    summaries/Y8_ch67_short/67_flashquiz.rst



.. toctree::
    :maxdepth: 2
    :caption: 🤔⚡ Y8 Energy Summaries

    summaries/Y8_ch6/6A.rst
    summaries/Y8_ch6/6B.rst
    summaries/Y8_ch6/6C.rst
    summaries/Y8_ch6/6D.rst
    summaries/Y8_ch6/6_flashquiz.rst


.. toctree::
    :maxdepth: 2
    :caption: 🤔⚡ Y8 Energy Quizzes

    quizzes/Y8_ch6/6A_jumblewords.rst
    quizzes/Y8_ch6/6A_keyterms.rst
    quizzes/Y8_ch6/6A_mcq.rst
    quizzes/Y8_ch6/6B_jumblewords.rst
    quizzes/Y8_ch6/6B_keyterms.rst
    quizzes/Y8_ch6/6B_mcq.rst
    quizzes/Y8_ch6/6C_jumblewords.rst
    quizzes/Y8_ch6/6C_keyterms.rst
    quizzes/Y8_ch6/6C_mcq.rst
    quizzes/Y8_ch6/6D_jumblewords.rst
    quizzes/Y8_ch6/6D_keyterms.rst
    quizzes/Y8_ch6/6D_mcq.rst



.. toctree::
    :maxdepth: 2
    :caption: 🤔⚡ Y8 Electricity Summaries

    summaries/Y8_ch7/7A.rst
    summaries/Y8_ch7/7B.rst
    summaries/Y8_ch7/7C.rst
    summaries/Y8_ch7/7_flashquiz.rst


.. toctree::
    :maxdepth: 2
    :caption: 🤔⚡ Y8 Electricity Quizzes

    quizzes/Y8_ch7/7A_jumblewords.rst
    quizzes/Y8_ch7/7A_keyterms.rst
    quizzes/Y8_ch7/7A_mcq.rst
    quizzes/Y8_ch7/7B_jumblewords.rst
    quizzes/Y8_ch7/7B_keyterms.rst
    quizzes/Y8_ch7/7B_mcq.rst
    quizzes/Y8_ch7/7C_jumblewords.rst
    quizzes/Y8_ch7/7C_keyterms.rst
    quizzes/Y8_ch7/7C_mcq.rst


.. toctree::
    :maxdepth: 2
    :caption: 🧪 Prac Sequencing
    :numbered:

    prac_sequences/Y7_yeast.rst
    prac_sequences/Y8_SIS_pendulum.rst
    prac_sequences/Y8_SIS_rulerdrop.rst
    prac_sequences/Y8_SIS_rotocopter.rst


.. toctree::
    :maxdepth: 2
    :caption: 🧪⚖️ Prac Ethics
    :numbered:

    prac_ethics/ethics_introduction.rst
    prac_ethics/ethics_honesty.rst
    prac_ethics/ethics_fairness.rst
    prac_ethics/ethics_respect_for_others.rst
    prac_ethics/ethics_avoidance_of_harm.rst
    prac_ethics/ethics_doing_good.rst



.. toctree::
    :maxdepth: 2
    :caption: 🧪⛔ Prac Errors in science
    :numbered:

    prac_errors/errors_in_science.rst



.. toctree::
    :maxdepth: 2
    :caption: 🧪⛔ Prac Systematic Errors
    :numbered:

    prac_errors/errors_systematic.rst
    prac_errors/errors_zero.rst
    prac_errors/errors_calibration.rst
    prac_errors/errors_parallax.rst
    prac_errors/errors_method_limitation.rst
    prac_errors/errors_environmental_bias.rst
    prac_errors/errors_systematic_quiz.rst


.. toctree::
    :maxdepth: 2
    :caption: 🧪⛔ Prac Random Errors
    :numbered:

    prac_errors/errors_random.rst
    prac_errors/errors_resolution_limitation.rst
    prac_errors/errors_technique_variation.rst
    prac_errors/errors_environmental_variation.rst
    prac_errors/errors_random_quiz.rst


.. toctree::
    :maxdepth: 2
    :caption: 🧪⛔ Prac Personal Errors
    :numbered:

    prac_errors/errors_personal.rst
    prac_errors/errors_operator.rst
    prac_errors/errors_recording.rst
    prac_errors/errors_personal_quiz.rst


.. toctree::
    :maxdepth: 2
    :caption: 🧪🎯 Prac Experiment Sections
    :numbered:

    pracs/accuracy_and_precision.rst
    pracs/aims.rst
    pracs/aims_nominalisations.rst



.. toctree::
    :maxdepth: 2
    :caption: ⚡ 8 Energy SIS

    prac_physics/sis_introduction.rst
    prac_physics/sis_01_investigation_and_energy.rst
    prac_physics/sis_02_variables_aim_hypothesis.rst
    prac_physics/sis_03_method_safety_ethics.rst
    prac_physics/sis_04_results_graphs_trends.rst
    prac_physics/sis_05_accuracy_errors_improvements.rst
    prac_physics/sis_06_conclusion_command_words_quick_check.rst



.. toctree::
    :maxdepth: 2
    :caption: ⚡ 8 Resistance Prac

    prac_resistance/resistance_introduction.rst
    prac_resistance/resistance_01_background_materials.rst
    prac_resistance/resistance_02_variables_aim_hypothesis.rst
    prac_resistance/resistance_03_safety_diagram_method.rst
    prac_resistance/resistance_04_results_graph.rst
    prac_resistance/resistance_05_trends_theory_precision.rst
    prac_resistance/resistance_06_errors.rst
    prac_resistance/resistance_07_application_conclusion.rst



.. toctree::
    :maxdepth: 2
    :caption: 🧪👉 Procedures
    :numbered:

    procedures/procedure_transitivity.rst
    procedures/report_to_procedure.rst
    procedures/procedure_dependent_clauses.rst
    procedures/procedure_time.rst
    procedures/procedure_manner.rst
    procedures/procedure_cause.rst
    procedures/procedure_condition.rst



.. toctree::
    :maxdepth: 2
    :caption: ⚡ 8 Energy
    :numbered:

    Y8/physics/energy_quick_questions.rst
    Y8/physics/energy_quick_cloze.rst
    Y8/physics/energy_cloze.rst
    Y8/physics/energy_quiz.rst

    Y8/energy/energy_nominalisations.rst
    Y8/energy/energy_nominalisations2.rst
    Y8/energy/energy_nominalisation_sentences.rst

    Y8/energy/energy_adding_circumstances.rst
    Y8/energy/energy_adding_circumstances2.rst
    Y8/energy/energy_match_circumstances.rst


.. toctree::
    :maxdepth: 2
    :caption: ⚡ 8 Electicity
    :numbered:

    Y8/physics/electricity_embedded_clauses.rst


.. toctree::
    :maxdepth: 2
    :caption: 💎 Rocks
    :numbered:

    Y8/rocks/rocks_nominalisations.rst
    Y8/rocks/rocks_nominalisations2.rst
    Y8/rocks/rocks_action_processes.rst

    Y8/rocks/rocks_prepositional_phrases.rst
    Y8/rocks/rocks_adding_circumstances.rst



.. toctree::
    :maxdepth: 2
    :caption: 🌋 Earth
    :numbered:


    Y8/earth/earth_nominalisations.rst
    Y8/earth/earth_nominalisations2.rst
    Y8/earth/earth_nominalisation_sentences.rst

    Y8/earth/earth_adding_circumstances.rst
    Y8/earth/earth_adding_circumstances2.rst

    Y8/earth/earth_match_circumstances.rst



.. toctree::
    :maxdepth: 2
    :caption: 🧪 States of Matter and Mixtures
    :numbered:

    Y7/states_mixtures/states_mixtures_nominalisations.rst
    Y7/states_mixtures/states_mixtures_nominalisations2.rst
    Y7/states_mixtures/states_mixtures_nominalisations3.rst




.. toctree::
    :maxdepth: 1
    :caption: 👈🔢🎨🗂️👑🔍 Noun groups
    :numbered:

    noun_groups/noun_group.rst
    noun_groups/noun_describers_classifiers.rst
    noun_groups/noun_group_qualifiers.rst
    noun_groups/qualifiers_prepositional_phrases.rst

    noun_groups/qualifiers_prepositional_phrases_place.rst
    noun_groups/qualifiers_prepositional_phrases_time.rst

    noun_groups/qualifiers_prepositional_phrases_cause.rst
    noun_groups/qualifiers_prepositional_phrases_contigency.rst
    noun_groups/qualifiers_prepositional_phrases_manner.rst
    noun_groups/qualifiers_prepositional_phrases_accompaniment.rst

    noun_groups/qualifiers_prepositional_phrases_angle.rst
    noun_groups/qualifiers_prepositional_phrases_matter.rst
    noun_groups/qualifiers_prepositional_phrases_role.rst



.. toctree::
    :maxdepth: 2
    :caption: ✏️ Language features
    :numbered:

    clauses/clauses.rst

    clauses/clauses_independent.rst
    clauses/clauses_dependent.rst
    clauses/clauses_relative.rst
    clauses/clauses_interrupting.rst
    clauses/clauses_non_finite.rst
    clauses/clauses_embedded.rst
    clauses/clauses_minor.rst

    language/sentences.rst
    language/finite_and_nonfinite_verbs.rst
    language/complex_sentences.rst
    language/active_passive.rst
    language/Sequential_explanations.rst
    language/themes.rst
    language/theme_and_rheme.rst
    language/marked_themes.rst

    language/Stages_and_Phases.rst
    language/genre_procedure.rst

    language/grammatical_metaphor.rst


.. toctree::
    :maxdepth: 2
    :caption: 🔧 Nominalisation
    :numbered:

    language/nominalisation_verbs.rst


.. toctree::
    :maxdepth: 2
    :caption: ⏱️ Circumstances
    :numbered:

    language/circumstance_resources.rst
    language/circumstance_prepositional_phrases.rst
    language/circumstances_manner.rst


.. toctree::
    :maxdepth: 2
    :caption: ⚙️ Cause Effect
    :numbered:

    cause_and_effect/cause_and_effect_patterns.rst
    cause_and_effect/cause_and_effect_examples.rst
    cause_and_effect/cause_and_effect_questions.rst


.. toctree::
    :maxdepth: 2
    :caption: 🤔👀🧩 PRO
    :numbered:

    language/PRO.rst


.. toctree::
    :maxdepth: 2
    :caption: 🧪👉 Information Reports
    :numbered:

    reporting/information_reports.rst
    reporting/descriptive_report.rst
    reporting/classifying_report.rst
    reporting/compositional_report.rst
    reporting/comparative_report.rst




.. toctree::
    :maxdepth: 2
    :caption: 🧪 Chemistry
    :numbered:

    Y8/chemistry/PRO_Physical_Changes_declarative.rst
    Y8/chemistry/PRO_Physical_Changes_situational.rst
    Y8/chemistry/PRO_Physical_Changes_scaffold.rst

    Y8/chemistry/PRO_Chemical_Changes.rst
    Y8/chemistry/PRO_Chemical_Changes_B.rst



.. toctree::
    :maxdepth: 2
    :caption: 🌜 Space
    :numbered:


.. toctree::
    :maxdepth: 2
    :caption: 🧲 Physics
    :numbered:
